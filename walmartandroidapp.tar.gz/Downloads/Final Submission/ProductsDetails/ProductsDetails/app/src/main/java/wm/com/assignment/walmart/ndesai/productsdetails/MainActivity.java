package wm.com.assignment.walmart.ndesai.productsdetails;

import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import wm.com.assignment.walmart.ndesai.productsdetails.adapter.ProductDetailsRecyclerViewAdapter;
import wm.com.assignment.walmart.ndesai.productsdetails.interfaces.ProductService;
import wm.com.assignment.walmart.ndesai.productsdetails.api.WalmartProductApi;
import wm.com.assignment.walmart.ndesai.productsdetails.models.AllProductsList;
import wm.com.assignment.walmart.ndesai.productsdetails.models.Product;
import wm.com.assignment.walmart.ndesai.productsdetails.utils.PaginationScrollListener;

public class MainActivity extends AppCompatActivity {


    private static final String TAG = "MainActivity";

    ProductDetailsRecyclerViewAdapter adapter;
    LinearLayoutManager linearLayoutManager;

    RecyclerView rv;
    ProgressBar progressBar;

    private static final int PAGE_START = 1;
    private boolean isLoading = false;
    private boolean isLastPage = false;
    // limiting to 5 for this tutorial, since total pages in actual API is very large. Feel free to modify.
    private int TOTAL_PAGES = 23;
    private int currentPage = PAGE_START;
    private static int PAGE_SIZE = 10;

    private ProductService productService;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rv = (RecyclerView) findViewById(R.id.main_recycler);
        progressBar = (ProgressBar) findViewById(R.id.main_progress);

        adapter = new ProductDetailsRecyclerViewAdapter(this);

        linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        rv.setLayoutManager(linearLayoutManager);

        rv.setItemAnimator(new DefaultItemAnimator());

        rv.setAdapter(adapter);

        rv.addOnScrollListener(new PaginationScrollListener(linearLayoutManager) {
            @Override
            protected void loadMoreItems() {
                isLoading = true;
                currentPage += 1;

                // mocking network delay for API call
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        loadNextPage();
                    }
                }, 1000);
            }

            @Override
            public int getTotalPageCount() {
                return TOTAL_PAGES;
            }

            @Override
            public boolean isLastPage() {
                return isLastPage;
            }

            @Override
            public boolean isLoading() {
                return isLoading;
            }
        });

        //init service and load data
        productService = WalmartProductApi.getClient().create(ProductService.class);

        loadFirstPage();

    }


    private void loadFirstPage() {
        Log.d(TAG, "loadFirstPage: ");

        callWmProductsApi().enqueue(new Callback<AllProductsList>() {
            @Override
            public void onResponse(Call<AllProductsList> call, Response<AllProductsList> response) {
                // Got data. Send it to adapter

                List<Product> results = fetchResults(response);
                progressBar.setVisibility(View.GONE);
                adapter.addAll(results);

                if (currentPage <= TOTAL_PAGES) adapter.addLoadingFooter();
                else isLastPage = true;
            }

            @Override
            public void onFailure(Call<AllProductsList> call, Throwable t) {
                t.printStackTrace();
            }
        });

    }

    /**
     * @param response extracts List<{@link Product>} from response
     * @return
     */
    private List<Product> fetchResults(Response<AllProductsList> response) {
        AllProductsList productList = response.body();
        return productList.getProducts();
    }

    private void loadNextPage() {
        Log.d(TAG, "loadNextPage: " + currentPage);

        callWmProductsApi().enqueue(new Callback<AllProductsList>() {
            @Override
            public void onResponse(Call<AllProductsList> call, Response<AllProductsList> response) {
                adapter.removeLoadingFooter();
                isLoading = false;

                List<Product> results = fetchResults(response);
                adapter.addAll(results);

                if (currentPage != TOTAL_PAGES) adapter.addLoadingFooter();
                else isLastPage = true;
            }

            @Override
            public void onFailure(Call<AllProductsList> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }


    /**
     * Performs a Retrofit call to the Walmart Product API
     * Same API call for Pagination.
     */
    private Call<AllProductsList> callWmProductsApi() {
        return productService.getAllProducts(currentPage, PAGE_SIZE);
    }

}
