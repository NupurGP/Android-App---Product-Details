package wm.com.assignment.walmart.ndesai.productsdetails.adapter;

import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.drawable.GlideDrawable;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;

import java.util.ArrayList;
import java.util.List;

import wm.com.assignment.walmart.ndesai.productsdetails.R;
import wm.com.assignment.walmart.ndesai.productsdetails.models.Product;
import wm.com.assignment.walmart.ndesai.productsdetails.product_details.ProductDetailsActivity;

public class ProductDetailsRecyclerViewAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int ITEM = 0;
    private static final int LOADING = 1;
    private static final String BASE_URL_IMG = "https://mobile-tha-server.appspot.com";

    public static List<Product> productResults;
    private Context context;

    private boolean isLoadingAdded = false;

    public ProductDetailsRecyclerViewAdapter(Context context) {
        this.context = context;
        productResults = new ArrayList<>();
    }

    public List<Product> getProducts() {
        return productResults;
    }

    public void setProducts(List<Product> productResults) {
        this.productResults = productResults;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder = null;
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());

        switch (viewType) {
            case ITEM:
                viewHolder = getViewHolder(parent, inflater);
                break;
            case LOADING:
                View v2 = inflater.inflate(R.layout.item_progress, parent, false);
                viewHolder = new LoadingVH(v2);
                break;
        }
        return viewHolder;
    }

    @NonNull
    private RecyclerView.ViewHolder getViewHolder(ViewGroup parent, LayoutInflater inflater) {
        RecyclerView.ViewHolder viewHolder;
        View v1 = inflater.inflate(R.layout.item_list, parent, false);
        viewHolder = new ProductVH(v1);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, int position) {

        Product result = productResults.get(position); // Movie

        switch (getItemViewType(position)) {
            case ITEM:
                final ProductVH productVH = (ProductVH) holder;

                productVH.mProductName.setText(result.getProductName());
                productVH.mProductShortDesc.setText(result.getShortDescription() != null ? (Html.fromHtml(result.getShortDescription())) : "");

                /**
                 * Using Glide to handle image loading.
                 */
                Glide
                        .with(context)
                        .load(BASE_URL_IMG + result.getProductImage())
                        .listener(new RequestListener<String, GlideDrawable>() {
                            @Override
                            public boolean onException(Exception e, String model, Target<GlideDrawable> target, boolean isFirstResource) {
                                // TODO: 08/11/16 handle failure
                                productVH.mProgress.setVisibility(View.GONE);
                                return false;
                            }

                            @Override
                            public boolean onResourceReady(GlideDrawable resource, String model, Target<GlideDrawable> target, boolean isFromMemoryCache, boolean isFirstResource) {
                                // image ready, hide progress now
                                productVH.mProgress.setVisibility(View.GONE);
                                return false;   // return false if you want Glide to handle everything else.
                            }
                        })
                        .diskCacheStrategy(DiskCacheStrategy.ALL)   // cache both original & resized image
                        .centerCrop()
                        .crossFade()
                        .into(productVH.mProductImage);

                productVH.displayArea.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent productDetails = new Intent(context, ProductDetailsActivity.class);
                        productDetails.putExtra("position", holder.getAdapterPosition());
                        context.startActivity(productDetails);
                    }
                });

                break;

            case LOADING:
//                Do nothing
                break;
        }

    }

    @Override
    public int getItemCount() {
        return productResults == null ? 0 : productResults.size();
    }

    @Override
    public int getItemViewType(int position) {
        return (position == productResults.size() - 1 && isLoadingAdded) ? LOADING : ITEM;
    }


    /*
   Helpers
    */

    public void add(Product r) {
        productResults.add(r);
        notifyDataSetChanged();
        notifyItemInserted(productResults.size() - 1);
    }

    public void addAll(List<Product> moveResults) {
        for (Product result : moveResults) {
            add(result);
        }
    }

    public void remove(Product r) {
        int position = productResults.indexOf(r);
        if (position > -1) {
            productResults.remove(position);
            notifyItemRemoved(position);
        }
    }

    public void clear() {
        isLoadingAdded = false;
        while (getItemCount() > 0) {
            remove(getItem(0));
        }
    }

    public boolean isEmpty() {
        return getItemCount() == 0;
    }


    public void addLoadingFooter() {
        isLoadingAdded = true;
        add(new Product());
    }

    public void removeLoadingFooter() {
        isLoadingAdded = false;

        int position = productResults.size() - 1;
        Product result = getItem(position);

        if (result != null) {
            productResults.remove(position);
            notifyItemRemoved(position);
        }
    }

    public Product getItem(int position) {
        return productResults.get(position);
    }


   /*
   View Holders
    */

    protected class ProductVH extends RecyclerView.ViewHolder {
        private TextView mProductName;
        private TextView mProductShortDesc;
        private ImageView mProductImage;
        private ProgressBar mProgress;
        private RelativeLayout displayArea;

        public ProductVH(View itemView) {
            super(itemView);

            mProductName = (TextView) itemView.findViewById(R.id.product_name);
            mProductShortDesc = (TextView) itemView.findViewById(R.id.product_short_desc);
            mProductImage = (ImageView) itemView.findViewById(R.id.product_image);
            mProgress = (ProgressBar) itemView.findViewById(R.id.loading_progress);
            displayArea = (RelativeLayout) itemView.findViewById(R.id.product_display_area);
        }
    }


    protected class LoadingVH extends RecyclerView.ViewHolder {

        public LoadingVH(View itemView) {
            super(itemView);
        }
    }
}

