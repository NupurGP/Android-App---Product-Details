package wm.com.assignment.walmart.ndesai.productsdetails.product_details;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.WindowManager;

import java.util.ArrayList;
import java.util.List;

import wm.com.assignment.walmart.ndesai.productsdetails.R;
import wm.com.assignment.walmart.ndesai.productsdetails.adapter.ProductDetailsViewPagerAdapter;
import wm.com.assignment.walmart.ndesai.productsdetails.models.Product;

public class ProductDetailsActivity extends AppCompatActivity {

    private int position;
    private ViewPager pager;

    @SuppressLint("RestrictedApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        getSupportActionBar().setDefaultDisplayHomeAsUpEnabled(true);

        setContentView(R.layout.activity_product_details);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);

        final Intent intent = getIntent();

        if (intent.hasExtra("position")) {
            position = intent.getIntExtra("position", 0);
        }

        setViews();

        setViewPager();


    }

    private void setViewPager() {
        pager.setAdapter(new ProductDetailsViewPagerAdapter(this));
        pager.post(new Runnable() {
            @Override
            public void run() {
                pager.setCurrentItem(position);
            }
        });
    }

    private void setViews() {
        pager = findViewById(R.id.viewpager);
    }

}
