package wm.com.assignment.walmart.ndesai.productsdetails.adapter;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v4.view.PagerAdapter;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.drawable.GlideDrawable;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;

import java.text.DecimalFormat;
import java.util.List;

import wm.com.assignment.walmart.ndesai.productsdetails.R;
import wm.com.assignment.walmart.ndesai.productsdetails.models.Product;


public class ProductDetailsViewPagerAdapter extends PagerAdapter {
    private Context context;
    private List<Product> productResults = ProductDetailsRecyclerViewAdapter.productResults;
    private LayoutInflater mLayoutInflater;
    private static final String BASE_URL_IMG = "https://mobile-tha-server.appspot.com";
    private TextView productName;
    private TextView productPrice;
    private TextView productRatings;
    private TextView reviewsCounts;
    private TextView productDesc;
    private RatingBar ratingbar;
    DecimalFormat df = new DecimalFormat("#.#");

    public ProductDetailsViewPagerAdapter(Context context) {
        this.context = context;
        mLayoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return productResults.size();
    }


    @Override
    public Object instantiateItem(ViewGroup container, int position) {

        View itemView = mLayoutInflater.inflate(R.layout.product_pager_item, container, false);
        productName = itemView.findViewById(R.id.product_name);
        productPrice = itemView.findViewById(R.id.product_price);
        productRatings = itemView.findViewById(R.id.product_ratings);
        reviewsCounts = itemView.findViewById(R.id.reviews_counts);
        productDesc = itemView.findViewById(R.id.product_description);
        ratingbar = itemView.findViewById(R.id.ratingbar_product);
        Resources rc = context.getResources();

        Product product = productResults.get(position);
        Glide
                .with(context)
                .load(BASE_URL_IMG + product.getProductImage())
                .listener(new RequestListener<String, GlideDrawable>() {
                    @Override
                    public boolean onException(Exception e, String model, Target<GlideDrawable> target, boolean isFirstResource) {
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(GlideDrawable resource, String model, Target<GlideDrawable> target, boolean isFromMemoryCache, boolean isFirstResource) {
                        return false;
                    }
                })
                .diskCacheStrategy(DiskCacheStrategy.ALL)   // cache both original & resized image
                .centerCrop()
                .crossFade()
                .into((ImageView) itemView.findViewById(R.id.img_photo));

        container.addView(itemView);

        float ratings = (float) (product.getReviewRating() != null ? product.getReviewRating() : 0);
        productName.setText(product.getProductName());
        productPrice.setText(product.getPrice() != null ? product.getPrice() : rc.getString(R.string.product_price_not_available));
        productRatings.setText(String.valueOf(df.format(ratings)));
        ratingbar.setRating(ratings);
        Drawable progress = ratingbar.getProgressDrawable();
        DrawableCompat.setTint(progress, rc.getColor(R.color.green_light));
        reviewsCounts.setText((product.getReviewCount() != null ? String.valueOf(product.getReviewCount()) : "0") + " " + rc.getString(R.string.product_reviews));
        productDesc.setText(product.getLongDescription() != null ? Html.fromHtml(product.getLongDescription()) : "");

        return itemView;

    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }


    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }
}
