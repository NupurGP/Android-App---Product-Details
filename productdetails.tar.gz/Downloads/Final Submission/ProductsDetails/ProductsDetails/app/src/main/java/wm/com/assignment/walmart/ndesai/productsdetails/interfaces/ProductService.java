package wm.com.assignment.walmart.ndesai.productsdetails.interfaces;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import wm.com.assignment.walmart.ndesai.productsdetails.models.AllProductsList;

public interface ProductService {

    @GET("/walmartproducts/{pageNumber}/{pageSize}")
    Call<AllProductsList> getAllProducts(@Path("pageNumber") Integer pageNumber,
                                         @Path("pageSize") Integer pageSize
    );
}
